SMART HOTEL ROOM ALLOCATION SYSTEM

1. Install Python 3.
2. Open Command Prompt in this folder.
3. Run:
   pip install -r requirements.txt
4. Run:
   python app.py
5. Open the local address shown by Flask (usually http://127.0.0.1:5000)

Project idea:
Allocate hotel rooms based on check-in/check-out times while reusing rooms whenever their bookings do not overlap.

Demo:
- Add a booking.
- Add another booking with overlapping dates; it gets another room.
- Add a booking after a previous guest checks out; the system can reuse that room.
- Cancel a booking to release its room.

Important:
This is a hackathon MVP, not a production hotel booking system.
