from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = "hackathon-secret-key"
DB = "hotel.db"

ROOMS = [
    (101, "Single"), (102, "Single"), (103, "Single"),
    (201, "Double"), (202, "Double"), (203, "Double"),
    (301, "Deluxe"), (302, "Deluxe"), (303, "Deluxe")
]

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute("""CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guest_name TEXT NOT NULL,
        room_no INTEGER NOT NULL,
        room_type TEXT NOT NULL,
        check_in TEXT NOT NULL,
        check_out TEXT NOT NULL
    )""")
    conn.commit()
    conn.close()

def room_available(conn, room_no, check_in, check_out):
    rows = conn.execute(
        """SELECT * FROM bookings
           WHERE room_no = ?
           AND check_in < ?
           AND check_out > ?""",
        (room_no, check_out, check_in)
    ).fetchall()
    return len(rows) == 0

def allocate_room(conn, check_in, check_out, preferred_type):
    # Reuse a room whenever its existing bookings do not overlap.
    for room_no, room_type in ROOMS:
        if preferred_type != "Any" and room_type != preferred_type:
            continue
        if room_available(conn, room_no, check_in, check_out):
            return room_no, room_type
    return None, None

@app.route("/")
def index():
    conn = get_db()
    bookings = conn.execute(
        "SELECT * FROM bookings ORDER BY check_in, room_no"
    ).fetchall()
    conn.close()

    total = len(ROOMS)
    return render_template("index.html", bookings=bookings, total=total)

@app.route("/book", methods=["POST"])
def book():
    guest_name = request.form["guest_name"].strip()
    check_in = request.form["check_in"]
    check_out = request.form["check_out"]
    preferred_type = request.form["room_type"]

    try:
        start = datetime.fromisoformat(check_in)
        end = datetime.fromisoformat(check_out)
    except ValueError:
        flash("Please enter valid dates and times.", "error")
        return redirect(url_for("index"))

    if not guest_name:
        flash("Guest name is required.", "error")
        return redirect(url_for("index"))

    if end <= start:
        flash("Check-out must be after check-in.", "error")
        return redirect(url_for("index"))

    conn = get_db()
    room_no, room_type = allocate_room(
        conn, check_in, check_out, preferred_type
    )

    if room_no is None:
        conn.close()
        flash("No suitable room is available for these dates.", "error")
        return redirect(url_for("index"))

    conn.execute(
        """INSERT INTO bookings
           (guest_name, room_no, room_type, check_in, check_out)
           VALUES (?, ?, ?, ?, ?)""",
        (guest_name, room_no, room_type, check_in, check_out)
    )
    conn.commit()
    conn.close()

    flash(f"Booking confirmed! Room {room_no} assigned.", "success")
    return redirect(url_for("index"))

@app.route("/cancel/<int:booking_id>", methods=["POST"])
def cancel(booking_id):
    conn = get_db()
    conn.execute("DELETE FROM bookings WHERE id = ?", (booking_id,))
    conn.commit()
    conn.close()
    flash("Booking cancelled and room released.", "success")
    return redirect(url_for("index"))

@app.route("/reset", methods=["POST"])
def reset():
    conn = get_db()
    conn.execute("DELETE FROM bookings")
    conn.commit()
    conn.close()
    flash("All demo bookings cleared.", "success")
    return redirect(url_for("index"))

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
